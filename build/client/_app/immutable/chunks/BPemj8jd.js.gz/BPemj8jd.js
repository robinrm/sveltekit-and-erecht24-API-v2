import{E as a}from"./DSIQN05n.js";a();
