const s=""+new URL("../assets/seal_privacy.BuqCsBR0.png",import.meta.url).href;export{s as l};
