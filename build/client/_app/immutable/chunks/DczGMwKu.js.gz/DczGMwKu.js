import{D as a}from"./BbrY2rfu.js";a();
