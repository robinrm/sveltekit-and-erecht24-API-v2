import{g as n,b as d}from"./DSIQN05n.js";function s(t,e,i){var a=n(t,e);a&&a.set&&(t[e]=i,d(()=>{t[e]=null}))}export{s as b};
