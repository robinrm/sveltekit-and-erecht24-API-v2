import{D as a}from"./D65nL8m3.js";a();
