import{d as i,e as n}from"./BbrY2rfu.js";function s(e,t,d){var a=i(e,t);a&&a.set&&(e[t]=d,n(()=>{e[t]=null}))}export{s as b};
