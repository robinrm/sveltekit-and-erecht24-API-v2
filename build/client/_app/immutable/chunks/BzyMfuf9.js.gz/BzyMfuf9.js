import{n as a}from"./CaePOEcs.js";a();
