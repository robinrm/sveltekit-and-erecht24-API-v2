import{l as o,a as r}from"../chunks/CX0G1jmO.js";export{o as load_css,r as start};
