import{a as t}from"../chunks/entry.ChGHFnb5.js";export{t as start};
