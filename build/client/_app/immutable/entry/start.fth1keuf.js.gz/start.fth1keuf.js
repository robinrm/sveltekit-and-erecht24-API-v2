import{a as t}from"../chunks/entry.D4q7OIXC.js";export{t as start};
